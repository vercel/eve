# @workflow/core

Core runtime package for [Workflow SDK](https://workflow-sdk.dev).

The CI benchmark suite in `e2e/benchmark.test.ts` measures time to first step,
fan-out, and sequential-step overhead. Streaming delivery performance is
measured in durabench; stream correctness remains covered by unit and E2E tests.

Steps wait for released stream writers to drain before recording completion,
then release idle transport resources when the World supports it. Reacquiring
the same writable remains supported. Aborting a public writable drains its
accepted prefix and disposes the underlying writer transport without closing
the shared server stream. Source failures in flushable readable pipes propagate
to the user-facing reader rather than leaving it waiting for more data.
Streams that finish draining after the inline wait budget expires do not force
an extra queued continuation unless other background operations remain pending.

Hook registration acknowledgements and token conflicts participate in replay
delivery ordering alongside step results, hook payloads, and sleep completions.
Concurrent branches awaiting `hook.getConflict()` preserve their step correlation
IDs when replaying an extended event history. `setAttributes()` acknowledgements
take part in the same ordering, so a branch awaiting `setAttributes()` while
another branch is in flight keeps its own step results on replay.

Hook disposals pending when a workflow completes or fails rely on the terminal
event's hook cleanup, avoiding redundant `hook_disposed` events. Disposals still
persist when the workflow suspends, a later pending registration needs the
same token, or explicit disposal releases a retained token early. Final
`AbortController.abort()` calls still propagate to steps.

Real-time abort streams use a 4-byte big-endian length envelope around the
existing serialized payload. Encryption and durable hook events are unchanged.
Readers accept both framed packets and older unframed packets, reassembling
split transport reads before hydration. Complete legacy packets propagate
without waiting for stream close. Cross-deployment `start()` keeps unframed
writes for targets whose core version predates abort framing or cannot be
established. `resumeHook()` retains unframed abort writes until its resume
context can attest the receiving runtime separately from the starting client.

Failed-run logs include underlying error causes and codes to help diagnose failures such as socket, DNS, and TLS errors. Unreadable causes are marked without preventing the run from being recorded as failed.

Queued step messages carry immutable run identity in `runContext`, so step
execution skips the initial `runs.get` and fetches the run row only when
continuing into workflow replay. Messages from older producers without
`runContext` retain the initial fetch.

When a World advertises `capabilities.invoke`, `resumeHook()` sends serialized
hook inputs through `world.invoke()` and waits for the executor's decision. The
World calls the existing handler with `invoke: true`, `requestId`, and the hook
input. Core validates the input, waits for its event write, and returns a
decision. Core shares a run's activity state between workflow execution and these
input calls.

The event write completes before the response is stored. On Worlds with
`hookResumeDedup`, a stable request identity makes retries reuse the same hook
event, including after hook disposal or run completion. Core can process inputs
while inline steps wait. Workflow code observes committed inputs at replay
boundaries, reusing a retained Node virtual machine when available.

Errors returned by the executor propagate through `world.invoke()` to the caller
of `resumeHook()`.

Register `onRunCompleted` and `onRunFailed` handlers with `registerLifecycleHooks`
from `workflow/api` for best-effort reporting of terminal transitions written by
your app. Handlers receive the workflow name without a backend read, a lazy `Run`
instance, and, for failures, an error hydrated from the persisted payload.
Callbacks are not retried; the event log remains the system of record.
Hook-property getters and reporting failures are isolated from terminal writes.
On Vercel, the callback's `waitUntil` scope also drains background operations for
streams hydrated from the persisted failure, including when a handler throws.
Cancel readers and release locks when finished; a leaked reader can hold that
scope open until the invocation's duration limit. Streams hydrated through
`run.returnValue` are not included in that drain.
Register in the workflow executor's host startup, never from workflow or step
code. Framework-specific support, hot-reload behavior, and stream cleanup are
documented in the [lifecycle hooks guide](https://workflow-sdk.dev/docs/observability/lifecycle-hooks).
