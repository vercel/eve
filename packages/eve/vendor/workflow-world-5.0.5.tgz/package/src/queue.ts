import { z } from 'zod/v4';
import { SerializedDataSchema } from './serialization.js';

export type QueueKind = 'workflow';

/**
 * Pattern matching valid queue prefixes:
 * - `__wkf_workflow_` (default, no namespace)
 * - `__{namespace}_wkf_workflow_` (namespaced)
 *
 * Namespace must be lowercase alphanumeric starting with a letter.
 */
export const QueuePrefix = z.compile(
  z
    .string()
    .regex(
      /^__(?:[a-z][a-z0-9]*_)?wkf_workflow_$/,
      'Must match __wkf_workflow_ or __{namespace}_wkf_workflow_'
    )
);
export type QueuePrefix = z.infer<typeof QueuePrefix>;

export const ValidQueueName = z.compile(
  z
    .string()
    .regex(
      /^__(?:[a-z][a-z0-9]*_)?wkf_workflow_.+$/,
      'Must be a valid queue name with a recognized prefix'
    )
);
export type ValidQueueName = z.infer<typeof ValidQueueName>;

const QueueNamespace = z.compile(
  z
    .string()
    .regex(
      /^[a-z][a-z0-9]*$/,
      'Must be lowercase alphanumeric, starting with a letter'
    )
);

/**
 * Resolves the active queue namespace from an explicit argument or the
 * `WORKFLOW_QUEUE_NAMESPACE` env var.
 */
export function resolveQueueNamespace(namespace?: string): string | undefined {
  return namespace ?? process.env.WORKFLOW_QUEUE_NAMESPACE ?? undefined;
}

/**
 * Builds the workflow queue topic prefix for an optional namespace.
 *
 * The literal kind argument is retained so existing workflow-only callers keep
 * their meaning after removal of the former `'step'` variant.
 *
 * - `getQueueTopicPrefix('workflow')` → `'__wkf_workflow_'`
 * - `getQueueTopicPrefix('workflow', 'custom')` → `'__custom_wkf_workflow_'`
 */
export function getQueueTopicPrefix(
  kind: QueueKind,
  namespace?: string
): QueuePrefix {
  if (kind !== 'workflow') {
    throw new Error(`Unsupported queue kind: ${kind}`);
  }
  if (namespace !== undefined) {
    QueueNamespace.parse(namespace);
    return `__${namespace}_wkf_workflow_` as QueuePrefix;
  }
  return '__wkf_workflow_' as QueuePrefix;
}

/**
 * The route a World that delivers over HTTP sends a prefix's messages to when
 * no other route or handler is registered for that prefix (see
 * {@link Queue.registerRoute}): the Workflow SDK's generated flow route,
 * relative to the app's base URL.
 */
export const WORKFLOW_FLOW_ROUTE = '/.well-known/workflow/v1/flow';

/**
 * Validates a delivery route for {@link Queue.registerRoute}: an absolute path
 * on the app's base URL (`/api/agent/queue`), with no query or fragment.
 * Returns it unchanged.
 */
export function parseQueueRoute(path: string): string {
  if (
    typeof path !== 'string' ||
    !path.startsWith('/') ||
    path.startsWith('//') ||
    /[?#\s]/.test(path)
  ) {
    throw new TypeError(
      `Invalid queue route "${String(path)}": must be an absolute path such as "/api/agent/queue", without a query or fragment`
    );
  }
  return path;
}

/**
 * The queue namespace a run's messages travel on, as recorded when the run was
 * created (`executionContext.queueNamespace`), or `undefined` when it recorded
 * none (or an invalid one), in which case the World's default namespace
 * applies. A World uses this to re-enqueue a run to its own consumer (see
 * `reenqueueActiveRuns`) rather than to the recovering process's prefix.
 */
export function getRunQueueNamespace(
  executionContext: unknown
): string | undefined {
  if (
    typeof executionContext !== 'object' ||
    executionContext === null ||
    executionContext instanceof Uint8Array
  ) {
    return undefined;
  }
  const namespace = (executionContext as { queueNamespace?: unknown })
    .queueNamespace;
  return typeof namespace === 'string' &&
    QueueNamespace.safeParse(namespace).success
    ? namespace
    : undefined;
}

export function parseQueueName(name: ValidQueueName): {
  prefix: QueuePrefix;
  id: string;
} {
  const match = name.match(/^(__(?:[a-z][a-z0-9]*_)?wkf_workflow_)(.+)$/);

  if (!match) {
    throw new Error(`Invalid queue name: ${name}`);
  }

  return {
    prefix: QueuePrefix.parse(match[1]),
    id: match[2],
  };
}

export const MessageId = z.compile(
  z.string().brand<'MessageId'>().describe('A stored queue message ID')
);
export type MessageId = z.infer<typeof MessageId>;

/**
 * OpenTelemetry trace context for distributed tracing
 */
export const TraceCarrierSchema = z.compile(z.record(z.string(), z.string()));
export type TraceCarrier = z.infer<typeof TraceCarrierSchema>;

/**
 * Run creation data carried through the queue for resilient start.
 * Only present on the first queue delivery: re-enqueues omit this.
 * When the runtime processes the message, it passes this data to the
 * run_started event so the server can create the run if it doesn't exist yet.
 */
export const RunInputSchema = z.compile(
  z
    .object({
      input: z.unknown(),
      deploymentId: z.string(),
      workflowName: z.string(),
      specVersion: z.number(),
      executionContext: z.record(z.string(), z.any()).optional(),
      /** Dynamic workflow code carried for resilient run creation. */
      dynamicWorkflowCode: SerializedDataSchema.optional(),
      /** Ref for deferred dynamic workflow code; mutually exclusive with bytes. */
      dynamicWorkflowCodeRef: z.string().optional(),
      /** Initial plaintext run attributes, for resilient run creation. */
      attributes: z.record(z.string(), z.string()).optional(),
      /**
       * Permits reserved `$`-prefixed keys in `attributes`, mirrored from the
       * `start()` option so resilient run creation validates the same way as
       * the original `run_created` attempt.
       */
      allowReservedAttributes: z.literal(true).optional(),
      /**
       * The run's X25519 public key, mirrored from `run_created` so a run the
       * resilient-start path creates can still receive sealed writes.
       */
      encryptionPublicKey: z.string().optional(),
      /**
       * The environment the creating client's writes are attributed to, as
       * reported by {@link World.getEnvironment} at `start()` time (on Vercel:
       * `'production' | 'preview' | 'development'`).
       *
       * This exists so the resilient-start path can be checked for a tenant
       * mismatch. `start()` writes `run_created` under the caller's own
       * credentials while pinning the queue message to a deployment, and those
       * two can disagree: if the message is consumed by a deployment in a
       * DIFFERENT environment, that consumer's `run_started` re-creates the run
       * under ITS tenant, so the same client-minted `wrun_` id ends up existing
       * in two environments: one stuck pending forever, the other executing.
       * Carrying the creator's environment lets the consumer compare it against
       * its own and refuse the delivery instead of forking the run.
       *
       * Absent for worlds with no environment dimension (local, Postgres), and
       * for older SDKs. Consumers must treat it as advisory and skip the check
       * when it is missing.
       */
      environment: z.string().optional(),
    })
    .refine(
      (value) =>
        value.dynamicWorkflowCode === undefined ||
        value.dynamicWorkflowCodeRef === undefined,
      {
        path: ['dynamicWorkflowCodeRef'],
        message:
          'dynamicWorkflowCode and dynamicWorkflowCodeRef are mutually exclusive',
      }
    )
);
export type RunInput = z.infer<typeof RunInputSchema>;

/**
 * Legacy lazy hook resume data carried through the queue alongside a workflow
 * invocation. Older producers publish this invocation and write no event of
 * their own. On receipt, a consumer that understands `hookInput` idempotently
 * ensures the `hook_received` event exists (keyed by `resumeId`) before
 * replaying, so repeated deliveries converge on exactly one event.
 *
 * The `payload` is the already-serialized (and possibly encrypted) resume
 * payload, and on this path the queue message is its only carrier. Every write
 * derived from this message therefore hashes to the same digest under the
 * `(runId, resumeId)` constraint.
 */
/**
 * Resilient step dispatch data carried through the queue alongside a
 * step-execution message ({@link WorkflowInvokePayload.stepId}). Present when
 * the producer (the suspension handler dispatching a newly created step)
 * parallelized the `step_created` event write with the queue publish: the
 * same shape as resilient start (`runInput`) and the resilient hook resume
 * (`hookInput`).
 *
 * When the producer's `step_created` write fails transiently (429 / 5xx /
 * transport), the step entity may not exist when this message is consumed. A
 * consumer that understands `stepInput` idempotently re-ensures the
 * `step_created` event, keyed by the message's `stepId` (the step's
 * correlation id, unique per `(runId, correlationId)`), before executing, so
 * the producer's write and the consumer's re-ensure converge on exactly one
 * event.
 *
 * The `input` is the already-serialized (and possibly encrypted) step input:
 * the identical bytes the producer also sent on the direct `events.create`.
 *
 * The current `@workflow/core` runtime neither attaches nor reads this field:
 * it publishes a step message only after its `step_created` write. The schema
 * keeps accepting it so a message that carries it still parses.
 */
export const StepDispatchInputSchema = z.compile(
  z.object({
    /**
     * The serialized step input, reused verbatim from the direct write. Always
     * binary: producers only attach `stepInput` when the dehydrated input is a
     * `Uint8Array` and the run's queue transport preserves bytes (CBOR).
     * Validated here so a malformed or transport-mangled payload fails the
     * message parse instead of being silently written into a `step_created` as
     * non-binary data. `Buffer` is a `Uint8Array` subclass and passes.
     */
    input: z.custom<Uint8Array>((value) => value instanceof Uint8Array, {
      message: 'stepInput.input must be a Uint8Array',
    }),
  })
);
export type StepDispatchInput = z.infer<typeof StepDispatchInputSchema>;

/**
 * Immutable run identity carried on a step-execution message so the consumer
 * can start the step without a blocking `runs.get` round trip. Every field is
 * fixed for the life of a run (runs are pinned to their deployment), and the
 * producer holds the run row at dispatch time, so the copy can never go
 * stale. Run *status* is deliberately NOT carried: liveness is enforced by
 * the `step_started` claim itself, which the World rejects on a terminal run.
 *
 * Consumers that need the full run row for inline replay
 * still fetch it lazily; messages without this field (older producers) take
 * the legacy `runs.get` prologue.
 */
export const RunDispatchContextSchema = z.compile(
  z.object({
    /** The deployment the run is pinned to (`WorkflowRun.deploymentId`). */
    deploymentId: z.string(),
    /** The run's spec version (`WorkflowRun.specVersion`). */
    specVersion: z.number(),
    /** The run's start time as epoch ms (`WorkflowRun.startedAt`). Numeric so
     *  it survives both queue transports without Date revival concerns. */
    startedAt: z.number().optional(),
    /** The run's lineage root (its `$rootRunId` attribute, or its own id). */
    rootRunId: z.string().optional(),
  })
);
export type RunDispatchContext = z.infer<typeof RunDispatchContextSchema>;

export const HookResumeInputSchema = z.compile(
  z.object({
    /** Stable idempotency key minted once per `resumeHook()` call. */
    resumeId: z.string(),
    /** The hook being resumed. */
    hookId: z.string(),
    /**
     * The hook's token, written into the `hook_received` event's `eventData` so
     * the consumer's re-ensured event carries the same token the producer
     * would. Replay validates `eventData.token` against the `createHook` token.
     */
    token: z.string(),
    /** The serialized resume payload, reused verbatim from the direct write. */
    payload: z.unknown(),
    /**
     * Content digest of `payload`, computed once by the producer over the
     * serialized bytes and forwarded verbatim on both the direct `events.create`
     * and this queue message. The consumer forwards it back to the server so both
     * writers of the same `resumeId` record an identical digest on the
     * `(runId, resumeId)` constraint, required because the v4 payload ref is not
     * content-stable server-side.
     */
    payloadDigest: z.string(),
    /**
     * The deployment the run is pinned to, from the producer's resume context.
     * Lets the consumer detect a misrouted delivery with a cheap ambient
     * deployment-id comparison BEFORE its hoisted `hook_received` replay-preload
     * write: only a detected mismatch pays for the authoritative run fetch and
     * the deployment-affinity guard. Optional for queued-message compatibility:
     * messages from older producers omit it and skip the pre-write
     * check (the authoritative guard before replay still protects them).
     */
    deploymentId: z.string().optional(),
  })
);
export type HookResumeInput = z.infer<typeof HookResumeInputSchema>;

/**
 * Wall-clock boundaries of a hook-triggered resume, carried on the queue
 * message so the SDK can report end-to-end time-to-resume (TTR, entry into
 * `resumeHook()` through to the first line of the next durable step) and its
 * non-overlapping phase breakdown, as span attributes on that step's
 * `step.execute` span. See `runtime/resume-latency.ts` in `@workflow/core`.
 *
 * Two groups of fields:
 *
 * - Producer fields (`resumeRequestedAtMs`, `queuePublishRequestedAtMs`,
 *   `strategy`) are stamped by `resumeHook()` on the invocation message. They
 *   ride along on a deployment-affinity re-route unchanged, so a misrouted
 *   delivery's extra hop stays inside `queue_delivery`.
 * - Consumer fields (`consumerStartedAtMs`, `replayStartedAtMs`,
 *   `nextStepEncounteredAtMs`, `setupSource`) are filled in by the invocation
 *   that replayed the resume, and ONLY when it dispatches the next durable
 *   step to a separate queue invocation instead of running it inline. They let
 *   that invocation report the same single TTR measurement.
 *
 * Every field is advisory and the whole object is optional, in all three
 * directions that matter for a rolling deploy: a new producer's timing is
 * ignored by an old consumer, a new consumer reports no TTR for an old
 * message, and workflow-server never reads it at all.
 *
 * `strategy` and `setupSource` are deliberately typed as plain strings rather
 * than enums: an unrecognized value from a newer producer must not fail the
 * parse of the whole invocation payload (which would wedge the run), since it
 * is only ever forwarded to a span attribute.
 */
export const HookResumeTimingSchema = z.compile(
  z.object({
    /** Epoch ms at entry into `resumeHook()`: the start of the TTR window. */
    resumeRequestedAtMs: z.number(),
    /** Epoch ms immediately before the queue publish was requested. */
    queuePublishRequestedAtMs: z.number(),
    /**
     * Which `resumeHook()` dispatch path ran. Current producers always report
     * `sequential` (durable write, then wake); older producers may report
     * `lazy` or `parallel`.
     */
    strategy: z.string().optional(),
    /** Epoch ms the final consumer's queue handler was entered. */
    consumerStartedAtMs: z.number().optional(),
    /** Epoch ms this invocation's first replay pass began. */
    replayStartedAtMs: z.number().optional(),
    /** Epoch ms replay first encountered a durable step after the resume. */
    nextStepEncounteredAtMs: z.number().optional(),
    /** How the consumer initialized replay state: see `ResumeSetupSource`. */
    setupSource: z.string().optional(),
  })
);
export type HookResumeTiming = z.infer<typeof HookResumeTimingSchema>;

export const WorkflowInvokePayloadSchema = z.compile(
  z.object({
    runId: z.string(),
    /** Process this input and return the handler's result as response data. */
    invoke: z.literal(true).optional(),
    /** Identifies one input across retries, separately from the queue delivery ID. */
    requestId: z.string().optional(),
    input: z.unknown().optional(),
    traceCarrier: TraceCarrierSchema.optional(),
    requestedAt: z.coerce.date().optional(),
    /**
     * Consecutive replay divergences in this recovery chain and latest position.
     *
     * `eventIds` is every divergent event id in the chain, oldest first, so the
     * terminal failure can say whether each recovery replay diverged at the same
     * event or wandered. The producer bounds it to the recovery budget plus one.
     * `.catch(undefined)` on the field for the reason `hookResumeTiming` has it:
     * a malformed history must degrade to "no history" rather than fail the
     * parse of every delivery of this message. A consumer that predates the
     * field ignores it; a producer that predates it sends none, and the consumer
     * restarts the history from `eventId`.
     */
    replayDivergence: z
      .object({
        eventId: z.string(),
        count: z.number().int().positive(),
        eventIds: z.array(z.string()).optional().catch(undefined),
      })
      .optional(),
    /**
     * Re-invocations so far in this chain of stale-snapshot (precondition)
     * rejections. Counted on the message because the in-process restart budget
     * lives in the invocation closure and the queue's delivery count resets on
     * every fresh enqueue, so without this a permanently fenced run would cycle
     * forever instead of failing.
     */
    preconditionReinvocations: z.number().int().positive().optional(),
    /** Number of times this message has been re-enqueued due to server errors (5xx) */
    serverErrorRetryCount: z.number().int().optional(),
    /** Number of times this message has been re-routed after a deployment mismatch */
    deploymentMismatchRetryCount: z.number().int().nonnegative().optional(),
    /**
     * The wait this message is the delayed continuation for, and which attempt
     * in that wait's chain it is.
     *
     * Present only on wait-continuation messages. It exists so the invocation a
     * continuation wakes can recognize itself as that continuation: if the wait
     * is STILL pending when it replays — the continuation arrived before its
     * deadline — then its own idempotency key is already spent, and re-enqueueing
     * under the same key is silently dropped by the world's dedupe window. The
     * attempt number is what makes the next key fresh, so an early delivery
     * costs one extra hop instead of losing the wait's timer permanently.
     *
     * Counted on the message for the same reason as
     * {@link WorkflowInvokePayloadSchema.shape.preconditionReinvocations}: the
     * budget has to survive across invocations, and a fresh enqueue resets
     * anything the queue tracks itself. Absent on the first continuation, so a
     * producer that predates this field is indistinguishable from attempt 0 and
     * a consumer that predates it simply ignores the field.
     */
    /**
     * `.catch(undefined)` for the reason `hookResumeTiming` has it: this field
     * must never be able to fail the parse of the invocation payload. A
     * malformed value would otherwise throw on every delivery of the message
     * and burn the run's delivery budget. Degrading to `undefined` reads as
     * "not a continuation", which costs at worst the pre-attempt behavior for
     * that one wait rather than killing the run.
     */
    waitContinuation: z
      .object({
        correlationId: z.string(),
        attempt: z.number().int().nonnegative(),
      })
      .optional()
      .catch(undefined),
    /** Step ID for inline step execution in combined handler. If provided, the flow execution
     * will jump directly to execute the step with the given ID before doing an event replay. */
    stepId: z.string().optional(),
    /** Step name, sent alongside stepId to avoid loading the event log to resolve the name. */
    stepName: z.string().optional(),
    /** Run creation data, only present on the first queue delivery from start() */
    runInput: RunInputSchema.optional(),
    /**
     * Legacy lazy hook resume data. A consumer that understands this field
     * idempotently ensures the `hook_received` event exists (keyed by `resumeId`)
     * before replaying.
     */
    hookInput: HookResumeInputSchema.optional(),
    /**
     * Resilient step dispatch data, only present alongside `stepId` when the
     * producer parallelized the `step_created` write with this queue publish. A
     * consumer that understands this field idempotently ensures the
     * `step_created` event exists (keyed by `stepId`) before executing the step.
     */
    stepInput: StepDispatchInputSchema.optional(),
    /**
     * Immutable run identity for step-execution messages (`stepId` present).
     * Lets the consumer skip the blocking `runs.get` before starting the step.
     * See {@link RunDispatchContextSchema}.
     */
    runContext: RunDispatchContextSchema.optional(),
    /**
     * Hook-resume TTR timing. Present on both `resumeHook()` dispatch paths
     * (unlike legacy `hookInput`), and
     * forwarded onto a dispatched step message when the resuming invocation
     * hands the next durable step to another invocation. Purely observational.
     * See {@link HookResumeTimingSchema}.
     *
     * `.catch(undefined)` because this field must never be able to fail the
     * parse of the invocation payload: a malformed value (a NaN boundary, a
     * shape change from a future producer) would otherwise throw on every
     * delivery of that message and burn the run's delivery budget over a
     * telemetry field. Anything unparseable degrades to "no measurement".
     */
    hookResumeTiming: HookResumeTimingSchema.optional().catch(undefined),
  })
);

export type WorkflowInvokePayload = z.infer<typeof WorkflowInvokePayloadSchema>;
export type HealthCheckPayload = z.infer<typeof HealthCheckPayloadSchema>;

/**
 * Health check payload - used to verify that the queue pipeline
 * can deliver messages to the combined workflow endpoint.
 */
export const HealthCheckPayloadSchema = z.compile(
  z.object({
    __healthCheck: z.literal(true),
    correlationId: z.string(),
    /**
     * The run id the caller is about to create, when the probe is being used to
     * prepare a cross-deployment `start()`.
     *
     * The responder runs inside the target deployment, so it can derive that
     * run's public key locally from its own key material and return it in the
     * probe response. That lets the caller seal the workflow arguments without
     * a separate key lookup. Absent for probes issued for other reasons (CLI
     * health command, dashboard), in which case no key is returned.
     *
     * Deliberately not named `runId`: `runId` is the only required field of
     * `WorkflowInvokePayloadSchema`, and 4.x deployments parse queue payloads
     * with a union that tries the invoke schema before the health check. A
     * probe carrying `runId` is read there as "replay this run", which POSTs
     * `run_started` for a run that does not exist yet (404) and retries the
     * delivery, so the probe never answers.
     */
    probeRunId: z.string().optional(),
    /**
     * Legacy spelling of {@link probeRunId}, sent by 5.x callers released
     * before the rename. Accepted so those callers still get a public key
     * back from this deployment; never sent.
     */
    runId: z.string().optional(),
  })
);

/**
 * Health check MUST come first.
 *
 * Zod unions return the first matching member's output, and `z.object` strips
 * keys the matching member doesn't declare. A probe from an older caller can
 * carry the legacy `runId`, which also satisfies `WorkflowInvokePayloadSchema`
 * (whose only required field is `runId`). With the invoke member first,
 * parsing such a probe silently drops `__healthCheck` and `correlationId`, and
 * the runtime (which dispatches on `__healthCheck` before falling through to
 * the invoke schema) reinterprets the probe as "replay this run".
 *
 * Ordering health check first is safe in the other direction: it requires
 * `__healthCheck: true`, which an invoke payload never carries.
 */
export const QueuePayloadSchema = z.compile(
  z.union([HealthCheckPayloadSchema, WorkflowInvokePayloadSchema])
);
export type QueuePayload = z.infer<typeof QueuePayloadSchema>;

export interface QueueOptions {
  deploymentId?: string;
  idempotencyKey?: string;
  headers?: Record<string, string>;
  /** Delay message delivery by this many seconds */
  delaySeconds?: number;
  /** Spec version of the target run. Used to select the queue transport format. */
  specVersion?: number;
  /**
   * World-specific routing hint identifying the region the message should
   * be sent to (e.g. a Vercel compute region code such as `'iad1'`).
   *
   * Worlds that don't have a regional dimension ignore this field. For
   * `@workflow/world-vercel`, this overrides the region the underlying
   * `@vercel/queue` client uses to route the message; when omitted, the
   * region is resolved from the payload's tagged run ID, then from the
   * `VERCEL_REGION` environment variable, and finally defaults to `'iad1'`
   * (the pre-regional-routing behavior).
   */
  region?: string;
}

/**
 * Outcome of one message in a {@link Queue.queueBatch} call, in input order.
 *
 * `messageId: null` with no `error` means accepted for deferred processing
 * (the same "accepted, no ID yet" case {@link Queue.queue} reports), so
 * `error === undefined` is the success test, not a non-null `messageId`.
 */
export type QueueBatchResult =
  | { messageId: MessageId | null; error?: undefined }
  | {
      messageId: null;
      /** Human-readable failure description for this message. */
      error: string;
      /** Republishing the batch may succeed. */
      retryable: boolean;
    };

export interface InvokeOptions {
  /** Retries of one request reuse this key and the exact same payload. */
  idempotencyKey?: string;
  /** Maximum time to await a response. Timeout does not undo processing. */
  timeoutMs?: number;
}

export interface Queue {
  getDeploymentId(): Promise<string>;

  /**
   * Send an invocation to a run's executor. Must be enabled via capabilities.invoke.
   * An invocation carries an out-of-band request that must be processed by the
   * executor. The executor's response is propagated back and errors are rethrown
   * by invoke(). A transport error is an unknown outcome: the request may have
   * been successfully processed by the executor, for example, and the success
   * result may be lost.
   */
  invoke?(
    runId: string,
    payload: unknown,
    options?: InvokeOptions
  ): Promise<unknown>;

  /**
   * Returns true only when a queue error definitively means the explicitly
   * targeted deployment cannot receive the message. Unknown and transient
   * errors must return false so the current delivery can be retried safely.
   */
  isDeploymentUnavailableError?(error: unknown): boolean;

  /**
   * Enqueues a message to the specified queue.
   *
   * @param queueName - The name of the queue to which the message will be sent.
   * @param message - The content of the message to be sent to the queue.
   * @param opts - Optional parameters for the queue operation.
   */
  queue(
    queueName: ValidQueueName,
    message: QueuePayload,
    opts?: QueueOptions
  ): Promise<{ messageId: MessageId | null }>;

  /**
   * Enqueues several messages to the SAME logical queue in as few round trips
   * as the backing transport allows. Optional: callers MUST fall back to
   * per-message {@link Queue.queue} when a World does not implement it.
   *
   * Exists for wide fan-outs. Publishing an N-branch `Promise.all` one message
   * at a time costs N round trips through a bounded connection pool, and that
   * cost is paid before the fan-out's first step body runs, so it lands
   * directly on time-to-first-step.
   *
   * Contract:
   *
   * - Results are returned in input order, one per input message. Returning
   *   a different number of results than there were messages is a contract
   *   violation the runtime rejects the whole batch on: an omitted result is
   *   indistinguishable from a message that was never published, and reading
   *   it as success would strand that step with no error anywhere.
   * - Partial failure is normal. A rejected entry reports `error`; a
   *   `retryable` entry may succeed if the whole batch is published again.
   *   Implementations MUST NOT throw for a per-entry failure — reserve
   *   rejection for request-level failures where no entry outcome is known.
   * - Callers are expected to pass `opts.idempotencyKey` per message, because
   *   the recovery for both a request-level failure and a retryable entry is
   *   to republish the batch: without keys that redelivers the entries that
   *   already succeeded.
   * - Every message must target one logical `queueName`. Implementations are
   *   free to split the batch (by transport cap, or by any per-message routing
   *   dimension they derive from the payload, such as region or physical
   *   topic); the split must not be observable in the returned order.
   */
  queueBatch?(
    queueName: ValidQueueName,
    messages: readonly { message: QueuePayload; opts?: QueueOptions }[]
  ): Promise<QueueBatchResult[]>;

  /**
   * Creates an HTTP queue handler for processing messages from a specific queue.
   * A rejected handler must retry the same message with an incremented attempt.
   * With `invoke: true`, the return value is response data delivered by World.
   * Only ordinary wake results interpret `{ timeoutSeconds }` as queue control.
   *
   * `meta.messageId` SHOULD be stable across redeliveries of the same message
   * (one ID per enqueued message, reused on every delivery attempt). The
   * runtime's inline step ownership uses it as a liveness lease: the lazy
   * `step_started` records the handling invocation's messageId, and only a
   * delivery of that same message may re-execute the step before the
   * ownership lease expires (crash recovery via queue redelivery). A World
   * whose queue mints a fresh ID per delivery degrades gracefully: owner
   * redeliveries fall back to the delayed-backstop path instead of executing
   * immediately, adding recovery latency but never wedging or duplicating.
   *
   * `meta.deliveryCount`, when the World reports it, is 1 on a message's first
   * delivery and increments on every redelivery, whatever caused it (lease
   * lapse, a rejected handler, a `{ timeoutSeconds }` result). A World whose
   * queue cannot say leaves it `undefined`. `meta.createdAt`, when known, is
   * when the message was first enqueued, unchanged across its redeliveries.
   */
  createQueueHandler(
    queueNamePrefix: QueuePrefix,
    handler: (
      message: unknown,
      meta: {
        attempt: number;
        deliveryCount?: number;
        createdAt?: Date;
        queueName: ValidQueueName;
        messageId: MessageId;
        requestId?: string;
      }
    ) => Promise<unknown>
  ): (req: Request) => Promise<Response>;

  /**
   * Optional. Delivers every message whose queue name starts with `prefix` to
   * `handler` inside this process, without HTTP. For Worlds whose queue runs
   * in the app's own process (world-local, world-postgres). `handler` takes
   * the same request a route serving `createQueueHandler(prefix, ...)` would,
   * so passing that route handler works. Takes precedence over
   * {@link Queue.registerRoute} for the prefix; a later registration for the
   * same prefix replaces an earlier one.
   *
   * Keyed by the exact prefix: registering `__wkf_workflow_` also takes the
   * Workflow SDK's own messages. A queue consumer other than the Workflow SDK
   * uses a prefix of its own, `__{namespace}_wkf_workflow_`.
   */
  registerHandler?(
    prefix: QueuePrefix,
    handler: (req: Request) => Promise<Response>
  ): void;

  /**
   * Optional. The route (a path on the app's base URL, such as
   * `/api/agent/queue`) that this World's HTTP delivery POSTs the messages of
   * `prefix` to. The app serves it with `createQueueHandler(prefix, ...)`.
   * A prefix without a registered route goes to the Workflow SDK's flow route
   * ({@link WORKFLOW_FLOW_ROUTE}), so only the Workflow SDK relies on that
   * path, and a queue consumer of its own registers its route here, before
   * the World's `start()` when it has one (`start()` re-enqueues active runs).
   * An in-process handler for the prefix ({@link Queue.registerHandler})
   * takes precedence; a later registration for the same prefix replaces an
   * earlier one.
   *
   * Worlds that deliver by subscription rather than by path (world-vercel)
   * do not implement this: subscribe the route to the prefix's topics there.
   */
  registerRoute?(prefix: QueuePrefix, path: string): void;
}
