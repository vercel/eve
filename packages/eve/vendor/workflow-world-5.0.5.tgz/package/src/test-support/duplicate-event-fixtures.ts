import type { EventType } from '../events.js';

/**
 * Logs that mix events a replay reads past with events that only look like it.
 *
 * Two codebases answer the same question about a log and must answer it the
 * same way. The runtime decides it while replaying: `EventsConsumer` passes
 * over an event whose class it already consumed for that entity and which
 * every registered callback declined. The observability UI decides it after
 * the fact, from the log alone, with no consumers to ask. It stands in for
 * them with the log's own record of when each entity finished, because that is
 * the point past which the runtime has no consumer left for the entity.
 *
 * Both apply the terminal-inert rule: once an entity's terminal event is in
 * the log, every later event for that entity is inert, whatever its class.
 *
 * The two rules agree on every fixture here, and the interesting ones are the
 * near misses: a retried step writes several `step_started` events that are
 * all consumed, and a step that is still open absorbs a second `step_created`.
 * Reading those as repeats would grey out attempts that ran.
 *
 * Each fixture is a whole run's log in log order, which is what both rules
 * take as input. Entities are named, not correlation-id shaped, so each side
 * can mint ids in whatever form it drives.
 */
export interface DuplicateEventFixtureEvent {
  eventType: EventType;
  /** The entity the event belongs to. Run-level events belong to none. */
  entity?: string;
}

export interface DuplicateEventFixture {
  name: string;
  /** What makes this log worth pinning down. */
  why: string;
  /** One run's whole log, in log order. */
  events: DuplicateEventFixtureEvent[];
  /**
   * Indices into {@link events} of the events no consumer claims: the ones the
   * runtime steps over and the UI greys out. Every other index is an event the
   * run acted on.
   */
  ignoredIndices: number[];
}

export const DUPLICATE_EVENT_FIXTURES: readonly DuplicateEventFixture[] = [
  {
    name: 'start after the step completed',
    why: 'A replay working from a prefix that predates the result re-invokes a step whose outcome is already recorded.',
    events: [
      { eventType: 'run_created' },
      { eventType: 'run_started' },
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_completed', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
    ],
    ignoredIndices: [5],
  },
  {
    name: 'retry attempts',
    why: 'Each attempt of a retried step writes its own start, and the live step consumer claims every one of them.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_retrying', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_retrying', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_completed', entity: 'step_a' },
    ],
    ignoredIndices: [],
  },
  {
    name: 'second creation of an open step',
    why: 'A step that has not finished still has a consumer, and it absorbs the repeat rather than leaving it unclaimed.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
    ],
    ignoredIndices: [],
  },
  {
    name: 'second outcome for one step',
    why: 'Completion and failure are one class, so the later outcome is a repeat of the earlier one whichever way round they land.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_failed', entity: 'step_a' },
      { eventType: 'step_completed', entity: 'step_a' },
    ],
    ignoredIndices: [3],
  },
  {
    name: 'start after the outcome, class not recorded yet',
    why: 'A background step invocation is not fenced, so one that stalled past its queue lease can write a start after the outcome another invocation recorded. The step is closed, so the start is inert even though no earlier start repeats it.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_completed', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
    ],
    ignoredIndices: [2],
  },
  {
    name: 'several stragglers after the outcome',
    why: 'Every event for a closed step is inert, so a redelivered attempt that writes a start and then a retry after the outcome changes nothing either.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_completed', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_retrying', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
    ],
    ignoredIndices: [3, 4, 5],
  },
  {
    name: 'retry recorded after the outcome',
    why: 'A retry repeats no earlier retry, so only the closed step makes it inert: after the outcome nothing claims any event for the step.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_failed', entity: 'step_a' },
      { eventType: 'step_retrying', entity: 'step_a' },
    ],
    ignoredIndices: [3],
  },
  {
    name: 'sleep recreated after it elapsed',
    why: 'Waits close on completion the way steps close on their outcome.',
    events: [
      { eventType: 'wait_created', entity: 'wait_a' },
      { eventType: 'wait_completed', entity: 'wait_a' },
      { eventType: 'wait_created', entity: 'wait_a' },
    ],
    ignoredIndices: [2],
  },
  {
    name: 'repeated hook deliveries',
    why: 'Deliveries belong to no class: a hook can be called any number of times, and every call is a call the run saw.',
    events: [
      { eventType: 'hook_created', entity: 'hook_a' },
      { eventType: 'hook_received', entity: 'hook_a' },
      { eventType: 'hook_received', entity: 'hook_a' },
      { eventType: 'hook_disposed', entity: 'hook_a' },
    ],
    ignoredIndices: [],
  },
  {
    name: 'second disposal of one hook',
    why: 'A hook closes on disposal, and both writers of a concurrent teardown can reach it. The write path rejects the second one, so the class entry is what covers a log that holds it anyway.',
    events: [
      { eventType: 'hook_created', entity: 'hook_a' },
      { eventType: 'hook_disposed', entity: 'hook_a' },
      { eventType: 'hook_disposed', entity: 'hook_a' },
    ],
    ignoredIndices: [2],
  },
  {
    name: 'hook recreated after it was disposed',
    why: 'Creation has a class of its own, so a stale replay re-creating a hook whose scope already exited is read past rather than treated as a new hook.',
    events: [
      { eventType: 'hook_created', entity: 'hook_a' },
      { eventType: 'hook_disposed', entity: 'hook_a' },
      { eventType: 'hook_created', entity: 'hook_a' },
    ],
    ignoredIndices: [2],
  },
  {
    name: 'two steps in flight',
    why: 'Classes are tracked per entity, so sibling steps running the same shape never collide.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_created', entity: 'step_b' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_b' },
      { eventType: 'step_completed', entity: 'step_b' },
      { eventType: 'step_completed', entity: 'step_a' },
    ],
    ignoredIndices: [],
  },
  {
    name: 'second attribute write under one id',
    why: 'A workflow-body attribute write resolves its id exactly once, so the second event under it is a straggler no consumer can take.',
    events: [
      { eventType: 'run_created' },
      { eventType: 'run_started' },
      { eventType: 'attr_set', entity: 'attr_a' },
      { eventType: 'attr_set', entity: 'attr_a' },
      { eventType: 'step_created', entity: 'step_b' },
      { eventType: 'step_started', entity: 'step_b' },
      { eventType: 'step_completed', entity: 'step_b' },
    ],
    ignoredIndices: [3],
  },
  {
    name: 'attribute writes from step bodies',
    why: 'A step-written attribute event names no entity, so several of them are several writes rather than repeats of one. Collapsing them would hide writes a run really made.',
    events: [
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
      { eventType: 'attr_set' },
      { eventType: 'attr_set' },
      { eventType: 'attr_set' },
      { eventType: 'step_completed', entity: 'step_a' },
    ],
    ignoredIndices: [],
  },
  {
    name: 'attribute writes from both sides of one run',
    why: 'The two shapes coexist: only the id-bearing repeat is read past, and the entity-less writes around it are untouched.',
    events: [
      { eventType: 'run_created' },
      { eventType: 'run_started' },
      { eventType: 'attr_set' },
      { eventType: 'attr_set', entity: 'attr_a' },
      { eventType: 'attr_set', entity: 'attr_a' },
      { eventType: 'attr_set' },
      { eventType: 'step_created', entity: 'step_b' },
    ],
    ignoredIndices: [4],
  },
  {
    name: 'two attribute writes at different body positions',
    why: 'Each call draws its own id, so consecutive attribute events are only repeats when the ids match.',
    events: [
      { eventType: 'attr_set', entity: 'attr_a' },
      { eventType: 'attr_set', entity: 'attr_b' },
      { eventType: 'step_created', entity: 'step_c' },
    ],
    ignoredIndices: [],
  },
  {
    name: 'second start of the run',
    why: 'Run events carry no correlation id and share one bucket. Two replays can each write a start, and the run has one.',
    events: [
      { eventType: 'run_created' },
      { eventType: 'run_started' },
      { eventType: 'run_started' },
      { eventType: 'step_created', entity: 'step_a' },
      { eventType: 'step_started', entity: 'step_a' },
    ],
    ignoredIndices: [2],
  },
];
