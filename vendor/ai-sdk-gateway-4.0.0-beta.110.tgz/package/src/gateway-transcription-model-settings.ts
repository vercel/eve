export type GatewayTranscriptionModelId = string & {};
